package com.example.rockvibe.ui.navigation

sealed class NavRoutes(val route: String) {
    object Splash : NavRoutes("splash")
    object Login : NavRoutes("login")

    // Admin
    object AdminDashboard : NavRoutes("admin_dashboard")
    object AdminUsers : NavRoutes("admin_users")
    object AdminProducts : NavRoutes("admin_products")
    object AdminSalesReport : NavRoutes("admin_sales_report")

    // Vendedor
    object SellerProducts : NavRoutes("seller_products")
    object SellerOrders : NavRoutes("seller_orders")
    object SellerProfile : NavRoutes("seller_profile")

    // Comprador
    object BuyerHome : NavRoutes("buyer_home")
    object BuyerProductDetail : NavRoutes("buyer_product_detail/{productId}") {
        fun createRoute(productId: String) = "buyer_product_detail/$productId"
    }
    object BuyerCart : NavRoutes("buyer_cart")
    object BuyerCheckout : NavRoutes("buyer_checkout")
    object BuyerProfile : NavRoutes("buyer_profile")
}
