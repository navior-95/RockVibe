package com.example.rockvibe.data.repository

import com.example.rockvibe.data.model.Product
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object ProductRepository {
    private val initialProducts = listOf(
        Product(
            id = "p1",
            title = "Guitarra Eléctrica Gibson Les Paul Standard",
            description = "Guitarra de edición especial RockVibe con cuerpo de caoba y pastillas Burstbucker Pro.",
            price = 2499.99,
            stock = 5,
            category = "Guitarras",
            sellerId = "u_seller1",
            sellerName = "Gibson Rock Store"
        ),
        Product(
            id = "p2",
            title = "Amplificador Marshall JVM410H",
            description = "Cabezal de 100W a tubos con 4 canales independientes y reverberación digital.",
            price = 1899.50,
            stock = 3,
            category = "Amplificadores",
            sellerId = "u_seller1",
            sellerName = "Gibson Rock Store"
        ),
        Product(
            id = "p3",
            title = "Batería Acústica Pearl Export EXX",
            description = "Set completo de 5 piezas con cascos de álamo y caoba asiática, herrajes incluidos.",
            price = 999.00,
            stock = 8,
            category = "Baterías",
            sellerId = "u_seller1",
            sellerName = "Gibson Rock Store"
        ),
        Product(
            id = "p4",
            title = "Pedal Overdrive Ibanez Tube Screamer TS9",
            description = "El pedal legendario de distorsión suave utilizado por los grandes del rock.",
            price = 129.90,
            stock = 15,
            category = "Efectos & Pedales",
            sellerId = "u_seller1",
            sellerName = "Gibson Rock Store"
        ),
        Product(
            id = "p5",
            title = "Bajo Eléctrico Fender Precision Bass",
            description = "Bajo de 4 cuerdas clásico con cuerpo de aliso y mástil de arce en acabado Sunburst.",
            price = 1150.00,
            stock = 4,
            category = "Bajos",
            sellerId = "u_seller1",
            sellerName = "Gibson Rock Store"
        )
    )

    private val _products = MutableStateFlow(initialProducts)
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    fun addProduct(product: Product) {
        _products.value = _products.value + product
    }

    fun updateProduct(product: Product) {
        _products.value = _products.value.map { if (it.id == product.id) product else it }
    }

    fun deleteProduct(productId: String) {
        _products.value = _products.value.filter { it.id != productId }
    }

    fun getProductById(productId: String): Product? {
        return _products.value.firstOrNull { it.id == productId }
    }
}
