package com.example.rockvibe.ui.seller

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.rockvibe.data.model.Product
import com.example.rockvibe.data.repository.AuthRepository
import com.example.rockvibe.data.repository.ProductRepository

@Composable
fun SellerProductsScreen() {
    val currentUser by AuthRepository.currentUser.collectAsState()
    val allProducts by ProductRepository.products.collectAsState()

    // Filtrar solo los productos del vendedor actual
    val sellerProducts = remember(allProducts, currentUser) {
        allProducts.filter { it.sellerId == (currentUser?.id ?: "u_seller1") }
    }

    var showProductDialog by remember { mutableStateOf(false) }
    var selectedProductForEdit by remember { mutableStateOf<Product?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedProductForEdit = null
                    showProductDialog = true
                }
            ) {
                Icon(Icons.Default.Add, contentDescription = "Nuevo Producto")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "Mis Productos (Vendedor)",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Gestión de catálogo y control de inventario",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (sellerProducts.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No tienes productos registrados en tu tienda.")
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(sellerProducts, key = { it.id }) { product ->
                        SellerProductItemCard(
                            product = product,
                            onEdit = {
                                selectedProductForEdit = product
                                showProductDialog = true
                            },
                            onDelete = {
                                ProductRepository.deleteProduct(product.id)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showProductDialog) {
        ProductFormDialog(
            product = selectedProductForEdit,
            sellerId = currentUser?.id ?: "u_seller1",
            sellerName = currentUser?.storeName ?: currentUser?.name ?: "Vendedor RockVibe",
            onDismiss = { showProductDialog = false },
            onSave = { prod ->
                if (selectedProductForEdit == null) {
                    ProductRepository.addProduct(prod)
                } else {
                    ProductRepository.updateProduct(prod)
                }
                showProductDialog = false
            }
        )
    }
}

@Composable
fun SellerProductItemCard(
    product: Product,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Store,
                contentDescription = null,
                modifier = Modifier.size(36.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = product.title, fontWeight = FontWeight.Bold)
                Text(
                    text = "Categoría: ${product.category}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Precio: $${product.price} | Stock: ${product.stock}",
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "Editar")
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun ProductFormDialog(
    product: Product?,
    sellerId: String,
    sellerName: String,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    var title by remember { mutableStateOf(product?.title ?: "") }
    var description by remember { mutableStateOf(product?.description ?: "") }
    var priceStr by remember { mutableStateOf(product?.price?.toString() ?: "") }
    var stockStr by remember { mutableStateOf(product?.stock?.toString() ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "Guitarras") }

    val categories = listOf("Guitarras", "Amplificadores", "Baterías", "Bajos", "Efectos & Pedales", "Accesorios")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (product == null) "Nuevo Producto" else "Editar Producto") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Título del Producto") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Descripción") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text("Precio ($)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = stockStr,
                        onValueChange = { stockStr = it },
                        label = { Text("Stock") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
                Text("Categoría:")
                Row(modifier = Modifier.fillMaxWidth()) {
                    ScrollableTabRow(
                        selectedTabIndex = categories.indexOf(category).coerceAtLeast(0),
                        edgePadding = 0.dp
                    ) {
                        categories.forEach { cat ->
                            Tab(
                                selected = category == cat,
                                onClick = { category = cat },
                                text = { Text(cat) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = priceStr.toDoubleOrNull() ?: 0.0
                    val stock = stockStr.toIntOrNull() ?: 0
                    val p = Product(
                        id = product?.id ?: "p_${System.currentTimeMillis()}",
                        title = title,
                        description = description,
                        price = price,
                        stock = stock,
                        category = category,
                        sellerId = sellerId,
                        sellerName = sellerName
                    )
                    onSave(p)
                }
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
