package com.example.rockvibe.data.model

data class Product(
    val id: String,
    val title: String,
    val description: String,
    val price: Double,
    val stock: Int,
    val category: String,
    val sellerId: String,
    val sellerName: String,
    val imageUrl: String = ""
)
