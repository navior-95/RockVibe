package com.example.rockvibe.ui.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.rockvibe.data.model.UserRole
import com.example.rockvibe.data.repository.AuthRepository
import com.example.rockvibe.data.repository.OrderRepository
import com.example.rockvibe.ui.admin.AdminDashboardScreen
import com.example.rockvibe.ui.admin.AdminProductsScreen
import com.example.rockvibe.ui.admin.AdminSalesReportScreen
import com.example.rockvibe.ui.admin.AdminUsersScreen
import com.example.rockvibe.ui.auth.LoginScreen
import com.example.rockvibe.ui.auth.PasswordRecoveryDialog
import com.example.rockvibe.ui.auth.SplashScreen
import com.example.rockvibe.ui.buyer.BuyerCartScreen
import com.example.rockvibe.ui.buyer.BuyerCheckoutScreen
import com.example.rockvibe.ui.buyer.BuyerHomeScreen
import com.example.rockvibe.ui.buyer.BuyerProductDetailScreen
import com.example.rockvibe.ui.buyer.BuyerProfileScreen
import com.example.rockvibe.ui.seller.SellerOrdersHistoryScreen
import com.example.rockvibe.ui.seller.SellerProductsScreen
import com.example.rockvibe.ui.seller.SellerProfileScreen
import kotlinx.coroutines.launch

data class BottomNavItem(
    val title: String,
    val route: String,
    val icon: ImageVector,
    val badgeCount: Int = 0
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold() {
    val navController = rememberNavController()
    val currentUser by AuthRepository.currentUser.collectAsState()
    val cart by OrderRepository.cart.collectAsState()
    val cartCount = cart.sumOf { it.quantity }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showPasswordRecoveryDialog by remember { mutableStateOf(false) }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val isTopLevelScreen = currentRoute != NavRoutes.Splash.route && currentRoute != NavRoutes.Login.route

    val currentRole = currentUser?.role ?: UserRole.COMPRADOR

    val bottomNavItems = remember(currentRole, cartCount) {
        when (currentRole) {
            UserRole.ADMIN -> listOf(
                BottomNavItem("Dashboard", NavRoutes.AdminDashboard.route, Icons.Default.Dashboard),
                BottomNavItem("Usuarios", NavRoutes.AdminUsers.route, Icons.Default.Group),
                BottomNavItem("Productos", NavRoutes.AdminProducts.route, Icons.Default.Inventory),
                BottomNavItem("Ventas", NavRoutes.AdminSalesReport.route, Icons.Default.Analytics)
            )
            UserRole.VENDEDOR -> listOf(
                BottomNavItem("Productos", NavRoutes.SellerProducts.route, Icons.Default.Store),
                BottomNavItem("Pedidos", NavRoutes.SellerOrders.route, Icons.AutoMirrored.Filled.ReceiptLong),
                BottomNavItem("Perfil", NavRoutes.SellerProfile.route, Icons.Default.Person)
            )
            UserRole.COMPRADOR -> listOf(
                BottomNavItem("Inicio", NavRoutes.BuyerHome.route, Icons.Default.Home),
                BottomNavItem("Carrito", NavRoutes.BuyerCart.route, Icons.Default.ShoppingCart, badgeCount = cartCount),
                BottomNavItem("Perfil", NavRoutes.BuyerProfile.route, Icons.Default.Person)
            )
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = isTopLevelScreen,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(modifier = Modifier.height(24.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "rockVibe",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = currentUser?.name ?: "Usuario RockVibe",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = currentUser?.email ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        SuggestionChip(
                            onClick = { },
                            label = { Text("Rol Actual: ${currentRole.label}") }
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

                Text(
                    text = "Cambiar Rol de Prueba:",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                UserRole.entries.forEach { role ->
                    NavigationDrawerItem(
                        icon = {
                            Icon(
                                imageVector = when(role) {
                                    UserRole.ADMIN -> Icons.Default.AdminPanelSettings
                                    UserRole.VENDEDOR -> Icons.Default.Store
                                    UserRole.COMPRADOR -> Icons.Default.ShoppingBag
                                },
                                contentDescription = null
                            )
                        },
                        label = { Text(role.label) },
                        selected = currentRole == role,
                        onClick = {
                            AuthRepository.loginAsRole(role)
                            scope.launch { drawerState.close() }
                            val targetRoute = when(role) {
                                UserRole.ADMIN -> NavRoutes.AdminDashboard.route
                                UserRole.VENDEDOR -> NavRoutes.SellerProducts.route
                                UserRole.COMPRADOR -> NavRoutes.BuyerHome.route
                            }
                            navController.navigate(targetRoute) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.LockReset, contentDescription = null) },
                    label = { Text("Recuperar Contraseña") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        showPasswordRecoveryDialog = true
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null) },
                    label = { Text("Cerrar Sesión") },
                    selected = false,
                    onClick = {
                        AuthRepository.logout()
                        scope.launch { drawerState.close() }
                        navController.navigate(NavRoutes.Login.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                if (isTopLevelScreen) {
                    CenterAlignedTopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("rockVibe", fontWeight = FontWeight.Bold)
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menú")
                            }
                        },
                        actions = {
                            AssistChip(
                                onClick = { scope.launch { drawerState.open() } },
                                label = { Text(currentRole.label) },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        }
                    )
                }
            },
            bottomBar = {
                if (isTopLevelScreen && bottomNavItems.any { it.route == currentRoute }) {
                    NavigationBar {
                        bottomNavItems.forEach { item ->
                            val isSelected = currentRoute == item.route
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    if (item.badgeCount > 0) {
                                        BadgedBox(
                                            badge = { Badge { Text("${item.badgeCount}") } }
                                        ) {
                                            Icon(item.icon, contentDescription = item.title)
                                        }
                                    } else {
                                        Icon(item.icon, contentDescription = item.title)
                                    }
                                },
                                label = { Text(item.title) }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = NavRoutes.Splash.route,
                modifier = Modifier.padding(padding)
            ) {
                composable(NavRoutes.Splash.route) {
                    SplashScreen(
                        onSplashFinished = {
                            navController.navigate(NavRoutes.Login.route) {
                                popUpTo(NavRoutes.Splash.route) { inclusive = true }
                            }
                        }
                    )
                }

                composable(NavRoutes.Login.route) {
                    LoginScreen(
                        onLoginSuccess = { role ->
                            val dest = when(role) {
                                UserRole.ADMIN -> NavRoutes.AdminDashboard.route
                                UserRole.VENDEDOR -> NavRoutes.SellerProducts.route
                                UserRole.COMPRADOR -> NavRoutes.BuyerHome.route
                            }
                            navController.navigate(dest) {
                                popUpTo(NavRoutes.Login.route) { inclusive = true }
                            }
                        }
                    )
                }

                // Rutas Admin
                composable(NavRoutes.AdminDashboard.route) {
                    AdminDashboardScreen(
                        onNavigateToUsers = { navController.navigate(NavRoutes.AdminUsers.route) },
                        onNavigateToProducts = { navController.navigate(NavRoutes.AdminProducts.route) },
                        onNavigateToSalesReport = { navController.navigate(NavRoutes.AdminSalesReport.route) }
                    )
                }

                composable(NavRoutes.AdminUsers.route) {
                    AdminUsersScreen()
                }

                composable(NavRoutes.AdminProducts.route) {
                    AdminProductsScreen()
                }

                composable(NavRoutes.AdminSalesReport.route) {
                    AdminSalesReportScreen()
                }

                // Rutas Vendedor
                composable(NavRoutes.SellerProducts.route) {
                    SellerProductsScreen()
                }

                composable(NavRoutes.SellerOrders.route) {
                    SellerOrdersHistoryScreen()
                }

                composable(NavRoutes.SellerProfile.route) {
                    SellerProfileScreen(
                        onLogout = {
                            navController.navigate(NavRoutes.Login.route) {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    )
                }

                // Rutas Comprador
                composable(NavRoutes.BuyerHome.route) {
                    BuyerHomeScreen(
                        onProductClick = { productId ->
                            navController.navigate(NavRoutes.BuyerProductDetail.createRoute(productId))
                        }
                    )
                }

                composable(NavRoutes.BuyerProductDetail.route) { backStackEntry ->
                    val productId = backStackEntry.arguments?.getString("productId") ?: ""
                    BuyerProductDetailScreen(
                        productId = productId,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NavRoutes.BuyerCart.route) {
                    BuyerCartScreen(
                        onNavigateToCheckout = {
                            navController.navigate(NavRoutes.BuyerCheckout.route)
                        }
                    )
                }

                composable(NavRoutes.BuyerCheckout.route) {
                    BuyerCheckoutScreen(
                        onBack = { navController.popBackStack() },
                        onPaymentSuccess = {
                            navController.navigate(NavRoutes.BuyerHome.route) {
                                popUpTo(NavRoutes.BuyerHome.route) { inclusive = true }
                            }
                        }
                    )
                }

                composable(NavRoutes.BuyerProfile.route) {
                    BuyerProfileScreen(
                        onLogout = {
                            navController.navigate(NavRoutes.Login.route) {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    )
                }
            }
        }
    }

    if (showPasswordRecoveryDialog) {
        PasswordRecoveryDialog(
            initialEmail = currentUser?.email ?: "",
            onDismiss = { showPasswordRecoveryDialog = false }
        )
    }
}
