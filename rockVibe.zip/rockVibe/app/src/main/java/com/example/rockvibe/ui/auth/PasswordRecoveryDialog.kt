package com.example.rockvibe.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rockvibe.data.repository.AuthRepository

@Composable
fun PasswordRecoveryDialog(
    initialEmail: String = "",
    onDismiss: () -> Unit
) {
    var email by remember { mutableStateOf(initialEmail) }
    var recoveryResult by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.LockReset,
                contentDescription = "Recuperar contraseña",
                modifier = Modifier.size(36.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = { Text("Recuperación de Contraseña") },
        text = {
            Column {
                Text(
                    text = "Ingresa tu correo electrónico asociado a la cuenta de RockVibe para recibir las instrucciones de restablecimiento."
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Correo Electrónico") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                if (recoveryResult != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = recoveryResult!!,
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (email.isNotBlank()) {
                        recoveryResult = AuthRepository.recoverPassword(email)
                    } else {
                        recoveryResult = "Por favor ingresa un correo electrónico válido."
                    }
                }
            ) {
                Text("Enviar Enlace")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cerrar")
            }
        }
    )
}
