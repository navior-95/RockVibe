package com.example.rockvibe.data.repository

import com.example.rockvibe.data.model.CartItem
import com.example.rockvibe.data.model.Order
import com.example.rockvibe.data.model.OrderItem
import com.example.rockvibe.data.model.OrderStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object OrderRepository {
    private val initialOrders = listOf(
        Order(
            id = "ORD-9081",
            buyerId = "u_buyer1",
            buyerName = "Juan Pérez",
            sellerId = "u_seller1",
            items = listOf(
                OrderItem("p4", "Pedal Overdrive Ibanez Tube Screamer TS9", 129.90, 1)
            ),
            totalAmount = 129.90,
            status = OrderStatus.PAID,
            date = "2025-02-15 14:30",
            shippingAddress = "Calle 80 # 45-12, Bogotá"
        ),
        Order(
            id = "ORD-9082",
            buyerId = "u_buyer1",
            buyerName = "Juan Pérez",
            sellerId = "u_seller1",
            items = listOf(
                OrderItem("p1", "Guitarra Eléctrica Gibson Les Paul Standard", 2499.99, 1)
            ),
            totalAmount = 2499.99,
            status = OrderStatus.SHIPPED,
            date = "2025-02-18 10:15",
            shippingAddress = "Calle 80 # 45-12, Bogotá"
        )
    )

    private val _orders = MutableStateFlow(initialOrders)
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    fun addToCart(product: com.example.rockvibe.data.model.Product, quantity: Int = 1) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val existing = current[index]
            current[index] = existing.copy(quantity = existing.quantity + quantity)
        } else {
            current.add(CartItem(product, quantity))
        }
        _cart.value = current
    }

    fun updateCartQuantity(productId: String, quantity: Int) {
        if (quantity <= 0) {
            _cart.value = _cart.value.filter { it.product.id != productId }
        } else {
            _cart.value = _cart.value.map {
                if (it.product.id == productId) it.copy(quantity = quantity) else it
            }
        }
    }

    fun removeFromCart(productId: String) {
        _cart.value = _cart.value.filter { it.product.id != productId }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun checkout(buyerId: String, buyerName: String, address: String): Order? {
        val items = _cart.value
        if (items.isEmpty()) return null

        val orderItems = items.map {
            OrderItem(
                productId = it.product.id,
                productTitle = it.product.title,
                unitPrice = it.product.price,
                quantity = it.quantity
            )
        }
        val total = items.sumOf { it.product.price * it.quantity }
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

        val newOrder = Order(
            id = "ORD-${(1000..9999).random()}",
            buyerId = buyerId,
            buyerName = buyerName,
            sellerId = items.first().product.sellerId,
            items = orderItems,
            totalAmount = total,
            status = OrderStatus.PAID,
            date = dateFormat.format(Date()),
            shippingAddress = address
        )

        _orders.value = _orders.value + newOrder
        clearCart()
        return newOrder
    }

    fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        _orders.value = _orders.value.map {
            if (it.id == orderId) it.copy(status = newStatus) else it
        }
    }
}
