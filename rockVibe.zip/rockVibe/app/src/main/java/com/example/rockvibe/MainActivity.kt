package com.example.rockvibe

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.fragment.app.FragmentActivity
import com.example.rockvibe.ui.navigation.MainScaffold
import com.example.rockvibe.ui.theme.RockVibeTheme

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RockVibeTheme {
                MainScaffold()
            }
        }
    }
}
