package com.example.rockvibe.data.model

enum class OrderStatus(val label: String) {
    PENDING("Pendiente"),
    PAID("Pagado"),
    SHIPPED("Enviado"),
    DELIVERED("Entregado"),
    CANCELLED("Cancelado")
}

data class OrderItem(
    val productId: String,
    val productTitle: String,
    val unitPrice: Double,
    val quantity: Int
)

data class Order(
    val id: String,
    val buyerId: String,
    val buyerName: String,
    val sellerId: String,
    val items: List<OrderItem>,
    val totalAmount: Double,
    val status: OrderStatus,
    val date: String,
    val shippingAddress: String
)

data class CartItem(
    val product: Product,
    val quantity: Int
)
