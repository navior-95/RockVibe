package com.example.rockvibe.data.repository

import com.example.rockvibe.data.model.User
import com.example.rockvibe.data.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AuthRepository {
    val mockUsers = listOf(
        User(
            id = "u_admin",
            name = "Carlos Administrador",
            email = "admin@rockvibe.com",
            role = UserRole.ADMIN,
            phone = "+57 300 123 4567",
            biometricsEnabled = true
        ),
        User(
            id = "u_seller1",
            name = "Gibson Rock Store",
            email = "vendedor@rockvibe.com",
            role = UserRole.VENDEDOR,
            phone = "+57 310 987 6543",
            storeName = "Gibson Official Rock",
            biometricsEnabled = true
        ),
        User(
            id = "u_buyer1",
            name = "Juan Pérez",
            email = "comprador@rockvibe.com",
            role = UserRole.COMPRADOR,
            phone = "+57 320 555 7788",
            address = "Calle 80 # 45-12, Bogotá",
            biometricsEnabled = true
        )
    )

    private val _currentUser = MutableStateFlow<User?>(mockUsers.first { it.role == UserRole.COMPRADOR })
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _isBiometricEnabled = MutableStateFlow(true)
    val isBiometricEnabled: StateFlow<Boolean> = _isBiometricEnabled.asStateFlow()

    fun loginAsRole(role: UserRole) {
        val user = mockUsers.firstOrNull { it.role == role } ?: mockUsers.first()
        _currentUser.value = user
    }

    fun loginWithEmail(email: String): Boolean {
        val user = mockUsers.firstOrNull { it.email.equals(email, ignoreCase = true) }
        return if (user != null) {
            _currentUser.value = user
            true
        } else {
            false
        }
    }

    fun logout() {
        _currentUser.value = null
    }

    fun toggleBiometrics(enabled: Boolean) {
        _isBiometricEnabled.value = enabled
        _currentUser.value?.let { user ->
            _currentUser.value = user.copy(biometricsEnabled = enabled)
        }
    }

    fun recoverPassword(email: String): String {
        val exists = mockUsers.any { it.email.equals(email, ignoreCase = true) }
        return if (exists) {
            "Se ha enviado un enlace de recuperación al correo: $email"
        } else {
            "El correo $email no está registrado en el sistema."
        }
    }
}
