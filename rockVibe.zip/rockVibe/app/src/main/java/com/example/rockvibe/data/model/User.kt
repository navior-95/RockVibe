package com.example.rockvibe.data.model

enum class UserRole(val label: String) {
    ADMIN("Administrador"),
    VENDEDOR("Vendedor"),
    COMPRADOR("Comprador")
}

data class User(
    val id: String,
    val name: String,
    val email: String,
    val role: UserRole,
    val phone: String = "",
    val biometricsEnabled: Boolean = false,
    val storeName: String? = null,
    val address: String = ""
)
